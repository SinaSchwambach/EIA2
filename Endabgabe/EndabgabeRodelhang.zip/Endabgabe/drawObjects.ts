namespace Endabgabe {

    export class DrawObject {
        xP: number;
        yP: number;
        xD: number;
        yD: number;
        colorBody: string;
        color: string;

        draw(): void {

        }

        move(): void {

        }

    }
}