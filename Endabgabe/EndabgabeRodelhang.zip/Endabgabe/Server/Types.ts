interface AssocStringString {
    [key: string]: string;
}

interface HighscoreData {
    name: string;
    highscore: number;
}
