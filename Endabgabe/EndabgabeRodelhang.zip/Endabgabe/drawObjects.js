var Endabgabe;
(function (Endabgabe) {
    class DrawObject {
        draw() {
        }
        move() {
        }
    }
    Endabgabe.DrawObject = DrawObject;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=drawObjects.js.map